---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
--                                     Aircraft Countermeasure Flares                                  --
--                                          ##  fxmanifest.lua ##                                      --
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
-------------------------                        Notes:                         -------------------------
-- [#1.] Thanks to "Trusted Studios" for giving me permission to depend on their original code using a resource
-- called "ts_Flares" v1.1.0, intially bringing two flare visual variants & allowing me to release my own
-- version with the unique additions, modifications + configuration options explained below...

-- [#2.] "Aircraft Countermeasure Flares" is a standalone FiveM resource that adds a fully server-authoritative 
-- countermeasure flare system to any aircraft. It requires no framework (no ESX, QBCore, or vRP) and has
-- no external dependencies beyond standard FiveM natives.

-- # Every sensitive action — ammo consumption, cooldowns, jam rolls, and rearming — is validated and are 
-- processed on the server ~ as the client handles rendering, visual effects, audio, and key input.

-- # The system supports unlimited aircraft with per-aircraft configuration, dual ejection banks          
-- (left and right), four fire modes, damage-based jamming, zone-gated rearming with a progress timer,  
-- two HUD designs, three flare visual variants, and a public export API for missile guidance integration.

-- Script is completely free, do not support leaking.

-- Copyright (c) 2026 - Solived
-- Licensed under the terms contained in the LICENSE.pdf file.
-- Unauthorized redistribution or resale is prohibited.

---------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------- 

--                      --
-- Beginning of code:   --
--                      --

fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Solived'
name 'Solived-AircraftFlares'
description 'Astandalone FiveM resource that adds a fully server-authoritative countermeasure flare system to any aircraft, highly-configurable.'
version '2.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/server.lua'
}