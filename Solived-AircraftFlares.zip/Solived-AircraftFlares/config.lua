---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
--                                     Aircraft Countermeasure Flares                                  --
--                                            ##  shared.lua ##                                        --
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
-------------------------                        Notes:                         -------------------------
-- [#1.] Thanks to "Trusted Studios" for giving me permission to depend on their original code using a resource
-- called "ts_Flares" v1.1.0, intially bringing two flare visual variants & allowing me to release my own
-- version with the unique additions, modifications + configuration options explained below...

-- [#2.] "Aircraft Countermeasure Flares" is a standalone FiveM resource that adds a fully server-authoritative 
-- countermeasure flare system to any aircraft. It requires no framework (no ESX, QBCore, or vRP) and has
-- no external dependencies beyond standard FiveM natives.

-- # Every sensitive action — ammo consumption, cooldowns, jam rolls, and rearming — is validated and are 
-- processed on the server ~ as the client handles rendering, visual effects, audio, and key input.

-- # The system supports unlimited aircraft with per-aircraft configuration, dual ejection banks          
-- (left and right), four fire modes, damage-based jamming, zone-gated rearming with a progress timer,  
-- two HUD designs, three flare visual variants, and a public export API for missile guidance integration.

-- Script is completely free, do not support leaking.

-- Copyright (c) 2026 - Solived
-- Licensed under the terms contained in the LICENSE.pdf file.
-- Unauthorized redistribution or resale is prohibited.

---------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------- 

--                      --
-- Beginning of code:   --
--                      --


Config = {}

-- ============================================================
--  GENERAL
-- ============================================================

Config.Debug = false

-- Chat commands
Config.CommandName   = 'flares'      -- /flares <mode>   (set bank mode)
Config.RefillCommand = 'refillflares' -- /refillflares    (rearm at zone)

-- Default key binding for hold-to-deploy
Config.DefaultKey = 'Y'

-- ============================================================
--  SEAT RESTRICTION
--  enabled   false → any occupied seat may use the system
--  pilotOnly true  → only seat -1 (pilot) permitted
--  pilotOnly false → use allowedSeats table below
-- ============================================================

Config.SeatRestriction = {
    enabled   = true,
    pilotOnly = false,
    allowedSeats = {
        [-1] = true,   -- pilot
        [0]  = true    -- co-pilot / front passenger
    }
}

-- ============================================================
--  FLIGHT CHECKS
-- ============================================================

Config.RequireEngineOn   = true     -- engine must be running
Config.BlockWhenDestroyed = true    -- no deploy if vehicle is destroyed

Config.Checks = {
    altitudeEnabled = true,
    speedEnabled    = false
}

Config.MinimumAltitude = 7.5   -- metres above ground
Config.MinimumSpeed    = 12.0  -- m/s (~43 km/h)
Config.AllowOnGround   = false -- hard-block if all wheels are on ground

-- ============================================================
--  DEPLOY BEHAVIOUR
-- ============================================================

Config.Deploy = {
    -- Milliseconds between re-checking hold-key pressure.
    -- Lower = more responsive, higher = less network spam on full-auto hold.
    holdRateMs = 75,

    -- If true a single tap fires one burst; holding repeats with cooldown.
    -- If false only a single burst per key-press (tap only, no auto-repeat).
    allowHoldRepeat = true,

    -- Minimum milliseconds that must pass between hold-repeat triggers.
    -- Prevents network flood when allowHoldRepeat is true.
    holdRepeatIntervalMs = 120
}

-- ============================================================
--  DAMAGE / JAM SYSTEM
-- ============================================================

Config.Damage = {
    enabled = true,

    -- At or below this health the dispenser may jam randomly.
    jamHealthThreshold        = 650.0,
    jamChance                 = 0.28,

    -- At or below this health jam probability increases.
    severeJamHealthThreshold  = 350.0,
    severeJamChance           = 0.55,

    -- When jammed, cooldown is multiplied by this factor before next attempt.
    jamCooldownMultiplier     = 0.5
}

-- ============================================================
--  REARM / REFILL
-- ============================================================

Config.Rearm = {
    -- false = refillflares works anywhere (no zone required)
    useZones      = true,

    -- Time in ms the player must hold still while rearming
    durationMs    = 7000,

    -- Aircraft must be below maxSpeed to begin rearming
    requireStopped = true,
    maxSpeed       = 2.0,

    -- Admin-only refill command (server-side ACE check)
    -- true  → only players with the ace permission below may use /refillflares
    -- false → any allowed seat may use /refillflares
    adminOnly     = false,
    adminAce      = 'group.admin',

    zones = {
        { label = 'LSIA Hangar',   coords = vec3(-979.0,  -2995.0,  13.9), radius = 35.0 },
        { label = 'Fort Zancudo',  coords = vec3(-2133.0,  3254.0,  32.8), radius = 50.0 },
        { label = 'Carrier Deck',  coords = vec3( 3082.0, -4719.0,  15.0), radius = 65.0 }
    }
}

-- ============================================================
--  AUDIO
-- ============================================================

Config.Audio = {
    -- Set to true to request/release the DLC audio bank for the release SFX
    useReleaseBank = true,
    bank           = 'DLC_SM_Countermeasures_Sounds',
    releaseSound   = 'flares_released',
    releaseSet     = 'DLC_SM_Countermeasures_Sounds',

    -- Brief cockpit confirmation tone played on the owner client
    useCockpitTone = true,
    cockpitSound   = 'CONFIRM_BEEP',
    cockpitSet     = 'HUD_MINI_GAME_SOUNDSET'
}

-- ============================================================
--  FLARE PROJECTILE & VISUAL REPLICA
-- ============================================================

Config.Flare = {
    -- Speed passed to ShootSingleBulletBetweenCoords; -1 = game default
    projectileSpeed = -1.0,

    -- Milliseconds between each flare in a burst sequence
    burstIntervalMs = 120,

    -- How long the vehicle counts as "hot" (export: IsVehicleCountermeasureHot)
    hotDurationMs   = 2600,

    -- Angular half-cone behind the aircraft considered the "rear sector".
    -- Missiles inside this cone see full hotness; outside = reduced hotness.
    rearConeDegrees = 75.0,

    -- ── Visual replica object ───────────────────────────────
    visualReplica  = true,
    replicaModel   = `w_am_flare`,
    replicaLifeMs  = 6000,   -- total lifespan
    replicaFadeMs  = 3800,   -- fade starts this many ms before death

    -- Scale applied when creating the replica prop
    replicaScale   = 1.0,

    -- Velocity jitter applied perpendicular to the flight path
    replicaJitter  = 0.3,

    -- Base rearward kick applied to replica velocity (m/s)
    replicaEjectSpeed = 7.5,

    -- Downward drift applied to replica (m/s)
    replicaDropSpeed  = 1.8,

    -- ── Variant selection ───────────────────────────────────
    -- 'red'  → standard GTA flare appearance (no glow)
    -- 'gold' → military countermeasure appearance (warm glow)
    defaultVariant = 'gold',

    variants = {
        red = {
            weapon      = 'weapon_flaregun',
            glow        = false,
            tintEnabled = false
        },

        gold = {
            weapon        = 'weapon_flaregun',
            glow          = true,
            glowColor     = { r = 255, g = 190, b = 45 },
            glowRange     = 14.0,
            glowIntensity = 8.0,
            glowTimeMs    = 650,   -- glow fades after this many ms
            tintEnabled   = true,
            tintIndex     = 2
        },

        -- White phosphorus / IR decoy variant (cool-white tone)
        white = {
            weapon        = 'weapon_flaregun',
            glow          = true,
            glowColor     = { r = 240, g = 245, b = 255 },
            glowRange     = 18.0,
            glowIntensity = 10.0,
            glowTimeMs    = 800,
            tintEnabled   = true,
            tintIndex     = 0
        }
    }
}

-- ============================================================
--  HUD
-- ============================================================

Config.HUD = {
    enabled = true,

    -- 'tactical' → full panel with dual-bank bars and mode line
    -- 'compact'  → slim single-bar widget
    design = 'tactical',

    -- Screen-space positions (0.0 = top/left, 1.0 = bottom/right)
    Designs = {
        tactical = {
            x      = 0.885,
            y      = 0.805,
            scale  = 1.0,
            width  = 0.205,
            height = 0.118,

            accentColor      = { 255, 185,  45, 235 },
            textColor        = { 235, 242, 245, 240 },
            mutedColor       = { 145, 158, 165, 230 },
            readyColor       = {  90, 235, 135, 240 },
            cooldownColor    = { 255, 145,  70, 240 },
            jamColor         = { 255,  65,  65, 240 },
            backgroundColor  = {   8,  12,  15, 205 },
            panelColor       = {  18,  25,  30, 220 },
            barBackgroundColor = { 45,  52,  57, 220 }
        },

        compact = {
            x      = 0.885,
            y      = 0.875,
            scale  = 1.0,
            width  = 0.185,
            height = 0.064,

            accentColor      = {  90, 220, 255, 235 },
            textColor        = { 245, 248, 250, 240 },
            mutedColor       = { 155, 170, 180, 225 },
            readyColor       = { 100, 240, 145, 240 },
            cooldownColor    = { 255, 165,  75, 240 },
            jamColor         = { 255,  65,  65, 240 },
            backgroundColor  = {   5,   9,  13, 205 },
            barBackgroundColor = { 42,  50,  56, 220 }
        }
    }
}

-- ============================================================
--  AIRCRAFT PROFILES  (default values per category)
-- ============================================================

-- Default ammo loaded per side (total = 2×) for each profile
Config.DefaultProfileAmmo = {
    fighter = 300,
    heli    = 24,
    heavy   = 48
}

-- Cooldown in ms between bursts for each profile
Config.DefaultProfileCooldown = {
    fighter = 200,
    heli    = 4600,
    heavy   = 5600
}

-- Number of flares fired per activation for each profile
Config.DefaultProfileBurst = {
    fighter = 2,
    heli    = 2,
    heavy   = 4
}

-- Ejection point offsets per profile, split into left / right banks.
-- Each bank is a list of vec3 offsets in local vehicle space
-- (right, forward, up) relative to the aircraft's origin.
Config.Profiles = {
    fighter = {
        offsets = {
            left  = { vec3(-1.2, -4.2, -0.20), vec3(-1.9, -4.6, -0.15) },
            right = { vec3( 1.2, -4.2, -0.20), vec3( 1.9, -4.6, -0.15) }
        }
    },

    heli = {
        offsets = {
            left  = { vec3(-1.0, -3.2, -0.35), vec3(-1.6, -3.5, -0.35) },
            right = { vec3( 1.0, -3.2, -0.35), vec3( 1.6, -3.5, -0.35) }
        }
    },

    heavy = {
        offsets = {
            left  = { vec3(-2.3, -7.4, -0.25), vec3(-1.2, -7.4, -0.25) },
            right = { vec3( 1.2, -7.4, -0.25), vec3( 2.3, -7.4, -0.25) }
        }
    }
}

-- ============================================================
--  ALLOWED AIRCRAFT
--
--  Each entry key must match the exact GTA vehicle model name.
--  Per-aircraft overrides (all optional):
--    profile     → which offsets/defaults to use
--    ammo        → total flare count  (split evenly L/R)
--    cooldownMs  → ms between bursts
--    burstSize   → flares per burst
--    variant     → flare visual variant name
-- ============================================================

Config.AllowedAircraft = {
    -- ── Rockstar base-game & DLC ──────────────────────────────
    mogul      = { profile = 'heavy'  },
    rogue      = { profile = 'fighter' },
    seabreeze  = { profile = 'fighter' },
    tula       = { profile = 'heavy'  },
    bombushka  = { profile = 'heavy'  },
    lazer      = { profile = 'fighter' },
    hydra      = { profile = 'fighter' },
    volatol    = { profile = 'heavy'  },
    avenger    = { profile = 'heavy'  },

    hunter     = { profile = 'heli' },
    akula      = { profile = 'heli' },
    buzzard2   = { profile = 'heli' },
    buzzard    = { profile = 'heli' },
    skylift    = { profile = 'heli' },
    maverick   = { profile = 'heli' },
    annihilator  = { profile = 'heli' },
    annihilator2 = { profile = 'heli' },
    cargobob   = { profile = 'heli' },
    cargobob2  = { profile = 'heli' },
    cargobob3  = { profile = 'heli' },
    cargobob4  = { profile = 'heli' },

    -- ── Fixed-wing fighters ───────────────────────────────────
    a4         = { profile = 'fighter' },
    f5adv      = { profile = 'fighter' },
    lavi       = { profile = 'fighter' },
    f15c       = { profile = 'fighter' },
    f15e       = { profile = 'fighter' },
    f15i       = { profile = 'fighter' },
    f16netz    = { profile = 'fighter' },
    f16c       = { profile = 'fighter' },
    f16cas     = { profile = 'fighter' },
    f16demo    = { profile = 'fighter' },
    f16vista   = { profile = 'fighter' },
    f16i       = { profile = 'fighter' },
    f35a       = { profile = 'fighter' },
    f35av2     = { profile = 'fighter' },
    f35av3     = { profile = 'fighter' },
    f35c       = { profile = 'fighter' },
    efroni     = { profile = 'fighter' },
    sr22       = { profile = 'fighter' },

    -- ── Unmanned aerial vehicles ──────────────────────────────
    mq1        = { profile = 'fighter' },
    mq4c       = { profile = 'heavy'  },
    mq9        = { profile = 'fighter' },

    -- ── Heavy fixed-wing ──────────────────────────────────────
    ac130u     = { profile = 'heavy', ammo = 64, burstSize = 4 },
    kc135r     = { profile = 'heavy', ammo = 64, burstSize = 4 },
    c130sh1    = { profile = 'heavy', ammo = 64, burstSize = 4 },
    c130sh     = { profile = 'heavy', ammo = 64, burstSize = 4 },
    c130h      = { profile = 'heavy', ammo = 64, burstSize = 4 },
    c130j      = { profile = 'heavy', ammo = 64, burstSize = 4 },
    kc130j     = { profile = 'heavy', ammo = 64, burstSize = 4 },
    gulfiv     = { profile = 'heavy' },
    titan      = { profile = 'heavy', ammo = 56, burstSize = 4 },
    globe      = { profile = 'heavy', ammo = 64, burstSize = 4 },
    b200       = { profile = 'heavy' },
    rc135w     = { profile = 'heavy', ammo = 64, burstSize = 4 },
    ['b787-9'] = { profile = 'heavy' },
    tu134      = { profile = 'heavy' },

    -- ── Attack & utility helicopters ──────────────────────────
    longbow    = { profile = 'heli' },
    longbow2   = { profile = 'heli' },
    ah64e      = { profile = 'heli', ammo = 32, cooldownMs = 4000 },
    viper      = { profile = 'heli' },
    mh6        = { profile = 'heli' },
    mh53       = { profile = 'heli', ammo = 32 },
    kch53      = { profile = 'heli', ammo = 32 },
    s70a       = { profile = 'heli' },
    uh60v      = { profile = 'heli' },
    mh60a      = { profile = 'heli' },
    mh60b      = { profile = 'heli' },
    atalef     = { profile = 'heli' },
    panther    = { profile = 'heli' },
    uh1a       = { profile = 'heli' },
    uh1b       = { profile = 'heli' },
    uh1c       = { profile = 'heli' },
    valkyrie   = { profile = 'heli' },

    -- ── Civilian rotary ───────────────────────────────────────
    bell407    = { profile = 'heli' },
    as350      = { profile = 'heli' },
    ec135      = { profile = 'heli' }
}

-- ============================================================
--  NOTIFICATION TEXT
-- ============================================================

Config.Text = {
    notAllowed    = 'This aircraft has no flare dispenser.',
    notAllowedSeat = 'You are not authorised to use this system from your seat.',
    tooLow        = 'Too low to deploy flares.',
    tooSlow       = 'Not enough airspeed.',
    noAmmo        = 'No flares remaining.',
    cooldown      = 'Countermeasures cooling down.',
    jammed        = 'Countermeasure dispenser jammed.',
    rearming      = 'Rearming countermeasures...',
    rearmed       = 'Countermeasures rearmed.',
    noZone        = 'Not inside a designated rearm zone.',
    mustBeStopped = 'Aircraft must be stationary to rearm.',
    noPermission  = 'You do not have permission to use that command.'
}

-- ============================================================
--  SHARED HELPERS
-- ============================================================

---Returns the resolved configuration for a given aircraft model hash.
---@param model number  GTA model hash
---@return string|nil name, table|nil cfg
function GetAircraftConfig(model)
    for name, data in pairs(Config.AllowedAircraft) do
        if model == joaat(name) then
            local profile = data.profile or 'fighter'
            return name, {
                profile    = profile,
                ammo       = data.ammo       or Config.DefaultProfileAmmo[profile]     or 24,
                cooldownMs = data.cooldownMs  or Config.DefaultProfileCooldown[profile] or 4200,
                burstSize  = data.burstSize   or Config.DefaultProfileBurst[profile]    or 2,
                variant    = data.variant     or Config.Flare.defaultVariant            or 'gold'
            }
        end
    end
    return nil, nil
end

---Returns true + seat index when ped is in an allowed seat; false + nil otherwise.
---@param vehicle number
---@param ped    number
---@return boolean, number|nil
function IsAllowedSeat(vehicle, ped)
    if vehicle == 0 or ped == 0 then return false, nil end

    if not Config.SeatRestriction.enabled then
        return true, nil
    end

    if Config.SeatRestriction.pilotOnly then
        if GetPedInVehicleSeat(vehicle, -1) == ped then
            return true, -1
        end
        return false, nil
    end

    for seatIndex, allowed in pairs(Config.SeatRestriction.allowedSeats) do
        if allowed and GetPedInVehicleSeat(vehicle, seatIndex) == ped then
            return true, seatIndex
        end
    end

    return false, nil
end

---Conditional debug printer.
function DebugPrint(...)
    if Config.Debug then
        print('[Solived-AircraftFlares]', ...)
    end
end
