Author: Solived (version v2.0.0 - latest)
Original script "ts_Flares" by Trusted Studios, details below.
Copyright (c) 2026 - Trusted Studios | approved by Thomas.

>>> Overview:
1. Thanks to "Trusted Studios" for giving me (Solived) permission to depend on their original code using a resource
called "ts_Flares" v1.1.0, intially bringing two flare visual variants & allowing me to release my own
version with the unique additions, modifications + configuration options explained below...
2. "Aircraft Countermeasure Flares" is a standalone FiveM resource that adds a fully server-authoritative 
countermeasure flare system to any aircraft. It requires no framework (no ESX, QBCore, or vRP) and has
no external dependencies beyond standard FiveM natives.
# Every sensitive action — ammo consumption, cooldowns, jam rolls, and rearming — is validated and are 
processed on the server ~ as the client handles rendering, visual effects, audio, and key input.
# The system supports unlimited aircraft with per-aircraft configuration, dual ejection banks          
(left and right), four fire modes, damage-based jamming, zone-gated rearming with a progress timer,  
two HUD designs, three flare visual variants, and a public export API for missile guidance integration.


>>> Installation
1. Drop the "Solived-AircraftFlares" folder into your resources directory.
2. Add 'ensure Solived-AircraftFlares' to your server.cfg.
3. Open config.lua and add any custom aircraft to Config.AllowedAircraft.
4. If you want zone-locked rearming, verify or update the coords in Config.Rearm.zones for your map.
5. Start your server. The keybind registers automatically (Y); players can rebind in GTA keybind settings.
*No SQL, no exports to configure, no other resources required.*


Please enjoy my high quality resources for FiveM ~ all for free, open-source.
Make sure to follow LICENSE guidelines
Do not support leaking/server dumping.


==== Contact Details ====
Feel free to send a message, ask a question, partnership or whatever.

-- Solived's Dev Workspace --
Discord:
> https://discord.gg/zmcCeBMAXb
> @solived

-- Trusted Studios --
Discord: 
> https://discord.gg/p5U6nmEQRR
> @tabysi (Thomas)


-- Copyright (c) 2026 - Solived
-- Licensed under the terms contained in the LICENSE.pdf file.
-- Unauthorized redistribution or resale is prohibited.