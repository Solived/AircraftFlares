---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
--                                     Aircraft Countermeasure Flares                                  --
--                                            ##  server.lua ##                                        --
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
-------------------------                        Notes:                         -------------------------
-- [#1.] Thanks to "Trusted Studios" for giving me permission to depend on their original code using a resource
-- called "ts_Flares" v1.1.0, intially bringing two flare visual variants & allowing me to release my own
-- version with the unique additions, modifications + configuration options explained below...

-- [#2.] "Aircraft Countermeasure Flares" is a standalone FiveM resource that adds a fully server-authoritative 
-- countermeasure flare system to any aircraft. It requires no framework (no ESX, QBCore, or vRP) and has
-- no external dependencies beyond standard FiveM natives.

-- # Every sensitive action — ammo consumption, cooldowns, jam rolls, and rearming — is validated and are 
-- processed on the server ~ as the client handles rendering, visual effects, audio, and key input.

-- # The system supports unlimited aircraft with per-aircraft configuration, dual ejection banks          
-- (left and right), four fire modes, damage-based jamming, zone-gated rearming with a progress timer,  
-- two HUD designs, three flare visual variants, and a public export API for missile guidance integration.

-- Script is completely free, do not support leaking.

-- Copyright (c) 2026 - Solived
-- Licensed under the terms contained in the LICENSE.pdf file.
-- Unauthorized redistribution or resale is prohibited.

---------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------- 

--                      --
-- Beginning of code:   --
--                      --

local VehicleState = {}

-- ── Internal helpers ─────────────────────────────────────────

local function buildStateFromCfg(cfg)
    local half = math.floor(cfg.ammo / 2)
    return {
        leftAmmo       = half,
        rightAmmo      = cfg.ammo - half,
        maxLeftAmmo    = half,
        maxRightAmmo   = cfg.ammo - half,
        cooldownUntil  = 0,
        jammedUntil    = 0,
        bankMode       = 'both',
        alternateNext  = 'left',
        lastDeployAt   = 0
    }
end

local function getState(netId, vehicle)
    if VehicleState[netId] then
        return VehicleState[netId]
    end

    local _, cfg = GetAircraftConfig(GetEntityModel(vehicle))
    if not cfg then return nil end

    VehicleState[netId] = buildStateFromCfg(cfg)
    return VehicleState[netId]
end

local function totalAmmo(state)
    return (state.leftAmmo or 0) + (state.rightAmmo or 0)
end

local function getJamChance(vehicle)
    if not Config.Damage.enabled then return 0.0 end
    local hp = GetEntityHealth(vehicle)
    if hp <= Config.Damage.severeJamHealthThreshold then
        return Config.Damage.severeJamChance
    end
    if hp <= Config.Damage.jamHealthThreshold then
        return Config.Damage.jamChance
    end
    return 0.0
end

---Builds the HUD payload table from state.
local function hudPayload(state)
    return {
        leftAmmo      = state.leftAmmo,
        rightAmmo     = state.rightAmmo,
        maxLeftAmmo   = state.maxLeftAmmo,
        maxRightAmmo  = state.maxRightAmmo,
        cooldownUntil = state.cooldownUntil,
        jammedUntil   = state.jammedUntil,
        bankMode      = state.bankMode
    }
end

---Push an updated HUD payload to a single player.
local function pushHud(src, state)
    TriggerClientEvent('Solived-AircraftFlares:updateHud', src, hudPayload(state))
end

---Validate that ped is in the vehicle and in an allowed seat.
---Returns true on success, or sends a notify and returns false.
local function validateOccupant(src, vehicle, ped)
    if ped == 0 or GetVehiclePedIsIn(ped, false) ~= vehicle then
        return false
    end
    local ok = IsAllowedSeat(vehicle, ped)
    if not ok then
        TriggerClientEvent('Solived-AircraftFlares:notify', src, Config.Text.notAllowedSeat)
        return false
    end
    return true
end

---Validate vehicle exists and has a flare config.
---Returns cfg on success or nil (sends notify on failure).
local function validateVehicle(src, netId)
    local vehicle = NetworkGetEntityFromNetworkId(netId)
    if vehicle == 0 or not DoesEntityExist(vehicle) then return nil, nil end
    local _, cfg = GetAircraftConfig(GetEntityModel(vehicle))
    if not cfg then
        TriggerClientEvent('Solived-AircraftFlares:notify', src, Config.Text.notAllowed)
        return nil, nil
    end
    return vehicle, cfg
end

-- ── Rearm shared logic ────────────────────────────────────────

local function doRearm(src, vehicle, vehicleNetId)
    local ped = GetPlayerPed(src)
    if not validateOccupant(src, vehicle, ped) then return end

    local _, cfg = GetAircraftConfig(GetEntityModel(vehicle))
    if not cfg then
        TriggerClientEvent('Solived-AircraftFlares:notify', src, Config.Text.notAllowed)
        return
    end

    local state = getState(vehicleNetId, vehicle)
    if not state then return end

    local half = state.maxLeftAmmo
    state.leftAmmo      = half
    state.rightAmmo     = state.maxRightAmmo
    state.cooldownUntil = 0
    state.jammedUntil   = 0

    TriggerClientEvent('Solived-AircraftFlares:notify', src, Config.Text.rearmed)
    pushHud(src, state)
    DebugPrint(('rearm: player %d rearmed vehicle net %d'):format(src, vehicleNetId))
end

-- ── Network events ────────────────────────────────────────────

RegisterNetEvent('Solived-AircraftFlares:requestState', function(vehicleNetId)
    local src = source
    local vehicle = NetworkGetEntityFromNetworkId(vehicleNetId)
    if vehicle == 0 or not DoesEntityExist(vehicle) then
        TriggerClientEvent('Solived-AircraftFlares:updateHud', src, nil)
        return
    end

    local _, cfg = GetAircraftConfig(GetEntityModel(vehicle))
    if not cfg then
        TriggerClientEvent('Solived-AircraftFlares:updateHud', src, nil)
        return
    end

    pushHud(src, getState(vehicleNetId, vehicle))
end)

RegisterNetEvent('Solived-AircraftFlares:syncMode', function(vehicleNetId, mode)
    local src     = source
    local vehicle = NetworkGetEntityFromNetworkId(vehicleNetId)
    if vehicle == 0 or not DoesEntityExist(vehicle) then return end

    local ped = GetPlayerPed(src)
    if not validateOccupant(src, vehicle, ped) then return end

    local allowed = { left = true, right = true, both = true, alternate = true }
    if not allowed[mode] then return end

    local state = getState(vehicleNetId, vehicle)
    if not state then return end

    state.bankMode = mode
    pushHud(src, state)
    DebugPrint(('syncMode: player %d set mode=%s on net %d'):format(src, mode, vehicleNetId))
end)

RegisterNetEvent('Solived-AircraftFlares:deployRequest', function(vehicleNetId)
    local src     = source
    local vehicle = NetworkGetEntityFromNetworkId(vehicleNetId)
    if vehicle == 0 or not DoesEntityExist(vehicle) then return end

    local ped = GetPlayerPed(src)
    if ped == 0 then return end
    if GetVehiclePedIsIn(ped, false) ~= vehicle then return end

    if not validateOccupant(src, vehicle, ped) then return end

    local _, cfg = GetAircraftConfig(GetEntityModel(vehicle))
    if not cfg then
        TriggerClientEvent('Solived-AircraftFlares:notify', src, Config.Text.notAllowed)
        return
    end

    local state = getState(vehicleNetId, vehicle)
    if not state then return end

    local now = GetGameTimer()

    -- Jam still active from last attempt
    if now < state.jammedUntil then
        TriggerClientEvent('Solived-AircraftFlares:notify', src, Config.Text.jammed)
        pushHud(src, state)
        return
    end

    -- Normal cooldown
    if now < state.cooldownUntil then
        TriggerClientEvent('Solived-AircraftFlares:notify', src, Config.Text.cooldown)
        pushHud(src, state)
        return
    end

    -- Out of ammo
    if totalAmmo(state) <= 0 then
        TriggerClientEvent('Solived-AircraftFlares:notify', src, Config.Text.noAmmo)
        return
    end

    -- Jam roll
    local jamChance = getJamChance(vehicle)
    if jamChance > 0.0 and math.random() < jamChance then
        local jamCd = math.floor(cfg.cooldownMs * (Config.Damage.jamCooldownMultiplier or 0.5))
        state.jammedUntil  = now + jamCd
        state.cooldownUntil = now + jamCd
        TriggerClientEvent('Solived-AircraftFlares:notify', src, Config.Text.jammed)
        pushHud(src, state)
        DebugPrint(('jam: player %d vehicle net %d for %dms'):format(src, vehicleNetId, jamCd))
        return
    end

    -- ── Build release plan ────────────────────────────────────
    local selectedBanks
    if state.bankMode == 'left' then
        selectedBanks = { 'left' }
    elseif state.bankMode == 'right' then
        selectedBanks = { 'right' }
    elseif state.bankMode == 'alternate' then
        selectedBanks = { state.alternateNext }
        state.alternateNext = (state.alternateNext == 'left') and 'right' or 'left'
    else -- 'both'
        selectedBanks = { 'left', 'right' }
    end

    local releasePlan = {}
    local totalSpent  = 0

    for _, bank in ipairs(selectedBanks) do
        local ammoField = (bank == 'left') and 'leftAmmo' or 'rightAmmo'
        local available = state[ammoField]
        if available > 0 then
            local perBank
            if state.bankMode == 'both' then
                perBank = math.min(available, math.ceil(cfg.burstSize / 2))
            else
                perBank = math.min(available, cfg.burstSize)
            end
            if perBank > 0 then
                state[ammoField] = available - perBank
                totalSpent       = totalSpent + perBank
                releasePlan[#releasePlan + 1] = { bank = bank, count = perBank }
            end
        end
    end

    if totalSpent <= 0 then
        TriggerClientEvent('Solived-AircraftFlares:notify', src, Config.Text.noAmmo)
        return
    end

    state.cooldownUntil = now + cfg.cooldownMs
    state.lastDeployAt  = now

    local payload = {
        vehicleNetId   = vehicleNetId,
        aircraftModel  = GetEntityModel(vehicle),
        profile        = cfg.profile,
        plan           = releasePlan,
        burstIntervalMs = Config.Flare.burstIntervalMs,
        hotDurationMs   = Config.Flare.hotDurationMs,
        variant         = cfg.variant or Config.Flare.defaultVariant or 'gold',
        serverTime      = now
    }

    -- Owner gets the full deploy (actual projectiles + replica + audio)
    TriggerClientEvent('Solived-AircraftFlares:doDeployOwner', src, payload)
    -- Everyone else gets replica-only
    TriggerClientEvent('Solived-AircraftFlares:doDeployReplica', -1, payload, src)

    pushHud(src, state)
    DebugPrint(('deploy: player %d net %d plan=%d parts spent=%d'):format(src, vehicleNetId, #releasePlan, totalSpent))
end)

RegisterNetEvent('Solived-AircraftFlares:rearmRequest', function(vehicleNetId)
    local src     = source
    local vehicle = NetworkGetEntityFromNetworkId(vehicleNetId)
    if vehicle == 0 or not DoesEntityExist(vehicle) then return end
    doRearm(src, vehicle, vehicleNetId)
end)

-- ── Admin refill command ──────────────────────────────────────

RegisterCommand(Config.RefillCommand, function(src)
    if src == 0 then return end -- console

    -- Optional ACE gate
    if Config.Rearm.adminOnly and not IsPlayerAceAllowed(src, Config.Rearm.adminAce) then
        TriggerClientEvent('Solived-AircraftFlares:notify', src, Config.Text.noPermission)
        return
    end

    local ped     = GetPlayerPed(src)
    if ped == 0 then return end
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 then return end

    if not validateOccupant(src, vehicle, ped) then return end

    local vehicleNetId = NetworkGetNetworkIdFromEntity(vehicle)
    doRearm(src, vehicle, vehicleNetId)
end, false)

-- ── Cleanup ───────────────────────────────────────────────────

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then
        VehicleState = {}
    end
end)
