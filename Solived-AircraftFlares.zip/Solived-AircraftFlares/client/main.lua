---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
--                                     Aircraft Countermeasure Flares                                  --
--                                            ##  client.lua ##                                        --
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
-------------------------                        Notes:                         -------------------------
-- [#1.] Thanks to "Trusted Studios" for giving me permission to depend on their original code using a resource
-- called "ts_Flares" v1.1.0, intially bringing two flare visual variants & allowing me to release my own
-- version with the unique additions, modifications + configuration options explained below...

-- [#2.] "Aircraft Countermeasure Flares" is a standalone FiveM resource that adds a fully server-authoritative 
-- countermeasure flare system to any aircraft. It requires no framework (no ESX, QBCore, or vRP) and has
-- no external dependencies beyond standard FiveM natives.

-- # Every sensitive action — ammo consumption, cooldowns, jam rolls, and rearming — is validated and are 
-- processed on the server ~ as the client handles rendering, visual effects, audio, and key input.

-- # The system supports unlimited aircraft with per-aircraft configuration, dual ejection banks          
-- (left and right), four fire modes, damage-based jamming, zone-gated rearming with a progress timer,  
-- two HUD designs, three flare visual variants, and a public export API for missile guidance integration.

-- Script is completely free, do not support leaking.

-- Copyright (c) 2026 - Solived
-- Licensed under the terms contained in the LICENSE.pdf file.
-- Unauthorized redistribution or resale is prohibited.

---------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------- 

--                      --
-- Beginning of code:   --
--                      --

-- ── State ─────────────────────────────────────────────────────

local HUD               = nil       -- latest HUD data pushed from server
local LastVehicleNetId  = nil       -- netId of the last aircraft we synced
local ActiveHotVehicles = {}        -- [vehicle] = expiry timestamp
local RearmInProgress   = false     -- true while the rearm progress bar runs
local HoldActive        = false     -- true while deploy key is held
local LastHoldFired     = 0         -- timestamp of the last hold-repeat trigger

-- ── Notification ─────────────────────────────────────────────

local function notify(msg)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)
end

RegisterNetEvent('Solived-AircraftFlares:notify', function(msg)
    notify(msg)
end)

-- ── Aircraft / seat helpers ───────────────────────────────────

local function getVehCfg(vehicle)
    if vehicle == 0 or not DoesEntityExist(vehicle) then return nil, nil end
    return GetAircraftConfig(GetEntityModel(vehicle))
end

local function isAllowedAircraft(vehicle)
    local _, cfg = getVehCfg(vehicle)
    return cfg ~= nil
end

local function isAllowedSeatLocal(vehicle)
    return IsAllowedSeat(vehicle, PlayerPedId())
end

-- ── Flight condition checks ───────────────────────────────────

local function getGroundClearance(vehicle)
    local c = GetEntityCoords(vehicle)
    local ok, gz = GetGroundZFor_3dCoord(c.x, c.y, c.z, false)
    return ok and (c.z - gz) or 9999.0
end

local function canDeploy(vehicle)
    if vehicle == 0 or not DoesEntityExist(vehicle) then
        return false, Config.Text.notAllowed
    end

    if not isAllowedSeatLocal(vehicle) then
        return false, Config.Text.notAllowedSeat
    end

    if Config.RequireEngineOn and not GetIsVehicleEngineRunning(vehicle) then
        return false, Config.Text.notAllowed
    end

    if Config.BlockWhenDestroyed and GetEntityHealth(vehicle) <= 0 then
        return false, Config.Text.notAllowed
    end

    if Config.Checks.speedEnabled and GetEntitySpeed(vehicle) < Config.MinimumSpeed then
        return false, Config.Text.tooSlow
    end

    if Config.Checks.altitudeEnabled then
        if not Config.AllowOnGround and IsVehicleOnAllWheels(vehicle) then
            return false, Config.Text.tooLow
        end
        if getGroundClearance(vehicle) < Config.MinimumAltitude then
            return false, Config.Text.tooLow
        end
    end

    if not isAllowedAircraft(vehicle) then
        return false, Config.Text.notAllowed
    end

    return true, nil
end

-- ── Flare variant helpers ─────────────────────────────────────

local function getFlareVariant(variantName)
    local v = (Config.Flare.variants or {})[variantName or Config.Flare.defaultVariant or 'gold']
    return v or { weapon = 'weapon_flaregun', glow = false, tintEnabled = false }
end

local function getVariantWeaponHash(variantCfg)
    local w = variantCfg.weapon or 'weapon_flaregun'
    return type(w) == 'number' and w or joaat(w)
end

-- ── Asset loading ─────────────────────────────────────────────

local function loadWeaponAsset(hash)
    RequestWeaponAsset(hash, 31, 0)
    local deadline = GetGameTimer() + 4000
    while not HasWeaponAssetLoaded(hash) and GetGameTimer() < deadline do
        Wait(0)
    end
    return HasWeaponAssetLoaded(hash)
end

local function loadModel(model)
    if not IsModelInCdimage(model) then return false end
    RequestModel(model)
    local deadline = GetGameTimer() + 3000
    while not HasModelLoaded(model) and GetGameTimer() < deadline do
        Wait(0)
    end
    return HasModelLoaded(model)
end

-- ── Audio helpers ─────────────────────────────────────────────

local function ensureAudioBank()
    if Config.Audio.useReleaseBank then
        RequestScriptAudioBank(Config.Audio.bank, false)
    end
end

local function releaseAudioBank()
    if Config.Audio.useReleaseBank then
        ReleaseScriptAudioBank()
    end
end

local function playReleaseSound(vehicle)
    ensureAudioBank()
    if Config.Audio.useCockpitTone then
        PlaySoundFrontend(-1, Config.Audio.cockpitSound, Config.Audio.cockpitSet, false)
    end
    PlaySoundFromEntity(-1, Config.Audio.releaseSound, vehicle, Config.Audio.releaseSet, true, 0)
end

-- ── Draw helpers ──────────────────────────────────────────────

local function drawText2D(x, y, scale, text, color, align)
    color = color or { 255, 255, 255, 255 }
    SetTextFont(4)
    SetTextScale(scale, scale)
    SetTextColour(color[1], color[2], color[3], color[4])
    SetTextOutline()
    SetTextDropShadow()
    SetTextCentre(false)
    SetTextRightJustify(false)

    if align == 'right' then
        SetTextRightJustify(true)
        SetTextWrap(0.0, x)
    elseif align == 'center' then
        SetTextCentre(true)
    end

    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(x, y)
end

local function drawProgressBar(x, y, width, height, value, maxValue, fillColor, bgColor)
    local ratio = (maxValue and maxValue > 0) and math.max(0.0, math.min(1.0, value / maxValue)) or 0.0
    DrawRect(x, y, width, height, bgColor[1], bgColor[2], bgColor[3], bgColor[4])
    if ratio > 0.0 then
        local fw  = width * ratio
        local fx  = x - (width / 2.0) + (fw / 2.0)
        DrawRect(fx, y, fw, height, fillColor[1], fillColor[2], fillColor[3], fillColor[4])
    end
end

-- ── HUD rendering ─────────────────────────────────────────────

local function getHudDesign()
    local d = Config.HUD.Designs or {}
    return d[Config.HUD.design] or d.tactical or d.compact
end

local function buildHudData(design)
    local left     = HUD.leftAmmo      or 0
    local right    = HUD.rightAmmo     or 0
    local maxLeft  = HUD.maxLeftAmmo   or 0
    local maxRight = HUD.maxRightAmmo  or 0
    local total    = left  + right
    local maxTotal = maxLeft + maxRight
    local now      = GetGameTimer()
    local cdLeft   = math.max(0, (HUD.cooldownUntil or 0) - now)
    local jammed   = (HUD.jammedUntil or 0) > now
    local modeText = (HUD.bankMode or 'both'):upper()

    local statusText, statusColor
    if jammed then
        statusText  = 'JAMMED'
        statusColor = design.jamColor or { 255, 65, 65, 240 }
    elseif cdLeft > 0 then
        statusText  = ('CD %.1fs'):format(cdLeft / 1000.0)
        statusColor = design.cooldownColor
    else
        statusText  = 'READY'
        statusColor = design.readyColor
    end

    return {
        left       = left,
        right      = right,
        maxLeft    = maxLeft,
        maxRight   = maxRight,
        total      = total,
        maxTotal   = maxTotal,
        modeText   = modeText,
        statusText = statusText,
        statusColor = statusColor
    }
end

local function drawTacticalHUD(design, data)
    local s        = design.scale or 1.0
    local x, y    = design.x or 0.885, design.y or 0.805
    local w        = (design.width  or 0.205) * s
    local h        = (design.height or 0.118) * s
    local le       = x - w / 2.0
    local te       = y - h / 2.0

    -- Background
    DrawRect(x, y, w, h, design.backgroundColor[1], design.backgroundColor[2], design.backgroundColor[3], design.backgroundColor[4])
    -- Top accent bar
    DrawRect(x, te + 0.0025 * s, w, 0.005 * s, design.accentColor[1], design.accentColor[2], design.accentColor[3], design.accentColor[4])

    -- Header row
    drawText2D(le + 0.010 * s, te + 0.010 * s, 0.34 * s, 'CMDS // FLARE DISPENSER', design.accentColor, 'left')
    drawText2D(x + w / 2.0 - 0.010 * s, te + 0.010 * s, 0.31 * s, data.statusText, data.statusColor, 'right')

    -- Divider
    DrawRect(x, te + 0.041 * s, w - 0.016 * s, 0.0015 * s, design.mutedColor[1], design.mutedColor[2], design.mutedColor[3], 100)

    -- Ammo counts
    drawText2D(le + 0.010 * s, te + 0.047 * s, 0.29 * s, ('L  %03d'):format(data.left),  design.textColor, 'left')
    drawText2D(x + w / 2.0 - 0.010 * s, te + 0.047 * s, 0.29 * s, ('R  %03d'):format(data.right), design.textColor, 'right')

    -- Bank bars
    local barY = te + 0.073 * s
    local barW = (w - 0.031 * s) / 2.0
    drawProgressBar(le + 0.010 * s + barW / 2.0,    barY, barW, 0.008 * s, data.left,  data.maxLeft,  design.accentColor, design.barBackgroundColor)
    drawProgressBar(x  + 0.0055 * s + barW / 2.0,  barY, barW, 0.008 * s, data.right, data.maxRight, design.accentColor, design.barBackgroundColor)

    -- Footer row
    drawText2D(le + 0.010 * s, te + 0.086 * s, 0.28 * s, ('MODE  %s'):format(data.modeText), design.mutedColor, 'left')
    drawText2D(x + w / 2.0 - 0.010 * s, te + 0.086 * s, 0.28 * s, ('TOTAL  %d/%d'):format(data.total, data.maxTotal), design.textColor, 'right')
end

local function drawCompactHUD(design, data)
    local s     = design.scale or 1.0
    local x, y = design.x or 0.885, design.y or 0.875
    local w     = (design.width  or 0.185) * s
    local h     = (design.height or 0.064) * s
    local le    = x - w / 2.0
    local te    = y - h / 2.0

    -- Background
    DrawRect(x, y, w, h, design.backgroundColor[1], design.backgroundColor[2], design.backgroundColor[3], design.backgroundColor[4])
    -- Left accent stripe
    DrawRect(le + 0.0025 * s, y, 0.005 * s, h, design.accentColor[1], design.accentColor[2], design.accentColor[3], design.accentColor[4])

    -- Header
    drawText2D(le + 0.011 * s, te + 0.009 * s, 0.32 * s, 'FLARES', design.accentColor, 'left')
    drawText2D(x + w / 2.0 - 0.008 * s, te + 0.009 * s, 0.32 * s, ('%d/%d'):format(data.total, data.maxTotal), design.textColor, 'right')

    -- Combined bar
    drawProgressBar(x, te + 0.036 * s, w - 0.022 * s, 0.008 * s, data.total, data.maxTotal, design.accentColor, design.barBackgroundColor)

    -- Footer
    drawText2D(le + 0.011 * s, te + 0.044 * s, 0.25 * s, ('%s  L:%d R:%d'):format(data.modeText, data.left, data.right), design.mutedColor, 'left')
    drawText2D(x + w / 2.0 - 0.008 * s, te + 0.044 * s, 0.25 * s, data.statusText, data.statusColor, 'right')
end

local function drawHUD()
    if not Config.HUD.enabled or not HUD then return end
    local design = getHudDesign()
    if not design then return end

    local data = buildHudData(design)

    if Config.HUD.design == 'compact' then
        drawCompactHUD(design, data)
    else
        drawTacticalHUD(design, data)
    end
end

-- ── Ejection point helpers ────────────────────────────────────

local function getOffsets(profileName, bank)
    local prof = Config.Profiles[profileName]
    if not prof or not prof.offsets then return {} end
    return prof.offsets[bank] or {}
end

local function getEntityRightVector(entity)
    if GetEntityMatrix then
        local right, _, _, _ = GetEntityMatrix(entity)
        if right then return right end
    end
    -- Fallback: derive from forward vector
    local fwd = GetEntityForwardVector(entity)
    local r   = vec3(-fwd.y, fwd.x, 0.0)
    local len = #(r)
    return (len > 0.001) and (r / len) or vec3(1.0, 0.0, 0.0)
end

-- ── Flare physics & effects ───────────────────────────────────

local function applyFlareTint(ped, weaponHash, variantCfg)
    if not variantCfg.tintEnabled then return end
    GiveWeaponToPed(ped, weaponHash, 1, false, false)
    SetPedWeaponTintIndex(ped, weaponHash, variantCfg.tintIndex or 0)
end

local function shootVanillaFlare(vehicle, offset, variantCfg)
    local ped        = PlayerPedId()
    local weaponHash = getVariantWeaponHash(variantCfg)
    applyFlareTint(ped, weaponHash, variantCfg)

    local origin = GetEntityCoords(vehicle)
    local eject  = GetOffsetFromEntityInWorldCoords(vehicle, offset.x, offset.y, offset.z)

    ShootSingleBulletBetweenCoordsWithExtraParams(
        origin.x, origin.y, origin.z,
        eject.x,  eject.y,  eject.z,
        0, true, weaponHash, ped,
        true, true,
        Config.Flare.projectileSpeed,
        vehicle,
        false, false, false, true, true, false
    )
end

local function spawnReplica(vehicle, offset, variantCfg)
    if not Config.Flare.visualReplica then return end

    local model = Config.Flare.replicaModel
    if not loadModel(model) then return end

    local pos = GetOffsetFromEntityInWorldCoords(vehicle, offset.x, offset.y, offset.z)
    local obj = CreateObjectNoOffset(model, pos.x, pos.y, pos.z, false, false, false)
    if obj == 0 then return end

    SetEntityCollision(obj, false, false)
    SetEntityHasGravity(obj, true)
    SetEntityInvincible(obj, true)
    SetEntityDynamic(obj, true)

    if Config.Flare.replicaScale and Config.Flare.replicaScale ~= 1.0 then
        SetEntityLodDist(obj, 500)
    end

    local vel     = GetEntityVelocity(vehicle)
    local forward = GetEntityForwardVector(vehicle)
    local right   = getEntityRightVector(vehicle)
    local jitter  = ((math.random() * 2.0) - 1.0) * (Config.Flare.replicaJitter or 0.3)
    local eject   = Config.Flare.replicaEjectSpeed or 7.5
    local drop    = Config.Flare.replicaDropSpeed  or 1.8

    SetEntityVelocity(obj,
        vel.x - forward.x * eject + right.x * jitter,
        vel.y - forward.y * eject + right.y * jitter,
        vel.z - drop
    )

    -- Lifecycle thread for glow and fade
    local lifeMs    = Config.Flare.replicaLifeMs or 6000
    local fadeMs    = math.min(Config.Flare.replicaFadeMs or 0, lifeMs)
    local glowMs    = variantCfg.glowTimeMs or lifeMs
    local glowColor = variantCfg.glowColor  or { r = 255, g = 190, b = 45 }
    local glowRange = variantCfg.glowRange  or 14.0
    local glowInt   = variantCfg.glowIntensity or 8.0
    local startAt   = GetGameTimer()

    CreateThread(function()
        while DoesEntityExist(obj) do
            local elapsed = GetGameTimer() - startAt

            if elapsed >= lifeMs then break end

            -- Fade-out alpha
            if fadeMs > 0 and elapsed >= (lifeMs - fadeMs) then
                local progress = (elapsed - (lifeMs - fadeMs)) / fadeMs
                SetEntityAlpha(obj, math.floor(255 * (1.0 - progress)), false)
            end

            -- Dynamic light
            if variantCfg.glow and elapsed < glowMs then
                local p = GetEntityCoords(obj)
                DrawLightWithRange(p.x, p.y, p.z, glowColor.r, glowColor.g, glowColor.b, glowRange, glowInt)
            end

            Wait(0)
        end

        if DoesEntityExist(obj) then
            DeleteEntity(obj)
        end
    end)
end

local function setHot(vehicle, durationMs)
    ActiveHotVehicles[vehicle] = GetGameTimer() + durationMs
end

-- ── Deploy execution ──────────────────────────────────────────

local function executeDeploy(payload, isOwner)
    local vehicle = NetworkGetEntityFromNetworkId(payload.vehicleNetId)
    if vehicle == 0 or not DoesEntityExist(vehicle) then return end

    local _, cfg = getVehCfg(vehicle)
    if not cfg then return end

    local variantCfg = getFlareVariant(payload.variant or cfg.variant)

    -- Owner: load weapon, shoot real projectile + replica + audio
    -- Replica clients: replica prop + audio only
    if isOwner then
        local weaponHash = getVariantWeaponHash(variantCfg)
        if not loadWeaponAsset(weaponHash) then
            notify('Failed to load flare weapon asset.')
            return
        end
    end

    playReleaseSound(vehicle)

    CreateThread(function()
        for _, part in ipairs(payload.plan or {}) do
            local offsets = getOffsets(cfg.profile, part.bank)
            if #offsets == 0 then goto continue end

            for i = 1, part.count do
                local offset = offsets[((i - 1) % #offsets) + 1]
                if offset then
                    if isOwner then
                        shootVanillaFlare(vehicle, offset, variantCfg)
                    end
                    spawnReplica(vehicle, offset, variantCfg)
                    setHot(vehicle, payload.hotDurationMs or Config.Flare.hotDurationMs)
                end
                Wait(payload.burstIntervalMs or Config.Flare.burstIntervalMs)
            end

            ::continue::
        end

        releaseAudioBank()
    end)
end

RegisterNetEvent('Solived-AircraftFlares:doDeployOwner', function(payload)
    executeDeploy(payload, true)
end)

RegisterNetEvent('Solived-AircraftFlares:doDeployReplica', function(payload, ownerServerId)
    if ownerServerId == GetPlayerServerId(PlayerId()) then return end
    executeDeploy(payload, false)
end)

RegisterNetEvent('Solived-AircraftFlares:updateHud', function(data)
    HUD = data
end)

-- ── Deploy request ────────────────────────────────────────────

local function requestDeploy()
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) then return end

    local vehicle = GetVehiclePedIsIn(ped, false)
    local ok, reason = canDeploy(vehicle)
    if not ok then
        notify(reason)
        return
    end

    TriggerServerEvent('Solived-AircraftFlares:deployRequest', NetworkGetNetworkIdFromEntity(vehicle))
end

-- ── Commands & key bindings ───────────────────────────────────

-- Hold key
RegisterCommand('+' .. Config.CommandName, function()
    HoldActive = true
end, false)

RegisterCommand('-' .. Config.CommandName, function()
    HoldActive = false
end, false)

RegisterKeyMapping('+' .. Config.CommandName, 'Hold to deploy aircraft countermeasure flares', 'keyboard', Config.DefaultKey)

-- Bank mode selector: /flares <left|right|both|alternate>
RegisterCommand(Config.CommandName, function(_, args)
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) then return end

    local vehicle = GetVehiclePedIsIn(ped, false)
    if not isAllowedAircraft(vehicle) then
        notify(Config.Text.notAllowed)
        return
    end
    if not isAllowedSeatLocal(vehicle) then
        notify(Config.Text.notAllowedSeat)
        return
    end

    local raw  = tostring(args[1] or ''):lower()
    local mode = (raw == 'all') and 'both' or raw

    if mode ~= 'left' and mode ~= 'right' and mode ~= 'both' and mode ~= 'alternate' then
        notify('Usage: /flares <left | right | both | alternate>')
        return
    end

    TriggerServerEvent('Solived-AircraftFlares:syncMode', NetworkGetNetworkIdFromEntity(vehicle), mode)
    notify(('Flare bank mode → %s'):format(mode:upper()))
end, false)

-- Rearm / refill: /refillflares
RegisterCommand(Config.RefillCommand, function()
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) then return end

    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 then return end

    if not isAllowedAircraft(vehicle) then
        notify(Config.Text.notAllowed)
        return
    end
    if not isAllowedSeatLocal(vehicle) then
        notify(Config.Text.notAllowedSeat)
        return
    end

    -- Zone check (client-side pre-filter; authoritative check is server-side)
    if Config.Rearm.useZones then
        local coords = GetEntityCoords(vehicle)
        local inZone = false
        for _, zone in ipairs(Config.Rearm.zones) do
            if #(coords - zone.coords) <= zone.radius then
                inZone = true
                break
            end
        end
        if not inZone then
            notify(Config.Text.noZone)
            return
        end

        if Config.Rearm.requireStopped and GetEntitySpeed(vehicle) > Config.Rearm.maxSpeed then
            notify(Config.Text.mustBeStopped)
            return
        end
    end

    if RearmInProgress then return end
    RearmInProgress = true
    notify(Config.Text.rearming)

    -- Progress timer
    local startAt  = GetGameTimer()
    local duration = Config.Rearm.durationMs

    while GetGameTimer() - startAt < duration do
        Wait(0)
        -- Block player from bailing / opening parachute during rearm
        DisableControlAction(0, 71, true)
        DisableControlAction(0, 72, true)
        DisableControlAction(0, 75, true)

        local remaining = (duration - (GetGameTimer() - startAt)) / 1000.0
        drawText2D(0.500, 0.880, 0.42,
            ('REARMING COUNTERMEASURES  %.1fs'):format(math.max(0.0, remaining)),
            { 255, 255, 255, 220 }, 'center')
    end

    TriggerServerEvent('Solived-AircraftFlares:rearmRequest', NetworkGetNetworkIdFromEntity(vehicle))
    RearmInProgress = false
end, false)

-- ── Chat suggestions ──────────────────────────────────────────

CreateThread(function()
    TriggerEvent('chat:addSuggestion', '/' .. Config.CommandName,
        'Set countermeasure flare bank mode',
        { { name = 'mode', help = 'left / right / both / alternate' } })
    TriggerEvent('chat:addSuggestion', '/' .. Config.RefillCommand,
        'Rearm aircraft flares at a designated zone')
end)

-- ── Main threads ──────────────────────────────────────────────

-- Hold-to-fire loop
CreateThread(function()
    local cfg = Config.Deploy or {}
    local rate      = cfg.holdRateMs          or 75
    local allowHold = cfg.allowHoldRepeat     ~= false
    local holdGap   = cfg.holdRepeatIntervalMs or 120

    while true do
        if HoldActive then
            if allowHold then
                local now = GetGameTimer()
                if now - LastHoldFired >= holdGap then
                    LastHoldFired = now
                    requestDeploy()
                end
            else
                -- Single trigger per press: server throttles further
                requestDeploy()
                HoldActive = false
            end
            Wait(rate)
        else
            Wait(100)
        end
    end
end)

-- Vehicle state sync tracker
CreateThread(function()
    while true do
        local ped = PlayerPedId()

        if IsPedInAnyVehicle(ped, false) then
            local vehicle = GetVehiclePedIsIn(ped, false)
            if isAllowedAircraft(vehicle) then
                local netId = NetworkGetNetworkIdFromEntity(vehicle)
                if netId ~= LastVehicleNetId then
                    LastVehicleNetId = netId
                    TriggerServerEvent('Solived-AircraftFlares:requestState', netId)
                end
                Wait(300)
            else
                HUD             = nil
                LastVehicleNetId = nil
                Wait(800)
            end
        else
            HUD             = nil
            LastVehicleNetId = nil
            Wait(800)
        end
    end
end)

-- HUD render loop
CreateThread(function()
    while true do
        if HUD then
            drawHUD()
            Wait(0)
        else
            Wait(500)
        end
    end
end)

-- Hot vehicle expiry cleanup
CreateThread(function()
    while true do
        local now = GetGameTimer()
        for veh, expiresAt in pairs(ActiveHotVehicles) do
            if expiresAt <= now or not DoesEntityExist(veh) then
                ActiveHotVehicles[veh] = nil
            end
        end
        Wait(500)
    end
end)

-- ── Export: countermeasure effectiveness query ────────────────
--
--  Usage from another resource:
--    local hot, hotness = exports.Solived-AircraftFlares:IsVehicleCountermeasureHot(vehicle, missileCoords)
--
--  Returns:
--    hot      (boolean) – true if flares are currently active on this vehicle
--    hotness  (number)  – 0.0–1.0 effectiveness score
--                         1.0 = missile is in rear hemisphere (full deflection chance)
--                         0.35 = missile is forward of the aircraft (reduced effectiveness)
--                         +0.15 bonus if extraBurst flag is true

exports('IsVehicleCountermeasureHot', function(vehicle, missileCoords, extraBurst)
    if vehicle == 0 or not DoesEntityExist(vehicle) then
        return false, 0.0
    end

    local expiresAt = ActiveHotVehicles[vehicle]
    if not expiresAt or expiresAt <= GetGameTimer() then
        return false, 0.0
    end

    local hotness   = 1.0
    local vehCoords = GetEntityCoords(vehicle)

    if missileCoords then
        local forward  = GetEntityForwardVector(vehicle)
        local toMissile = vec3(
            missileCoords.x - vehCoords.x,
            missileCoords.y - vehCoords.y,
            missileCoords.z - vehCoords.z
        )
        local len = #(toMissile)
        if len > 0.001 then
            toMissile = toMissile / len
            local dot   = forward.x * toMissile.x + forward.y * toMissile.y + forward.z * toMissile.z
            local angle = math.deg(math.acos(math.max(-1.0, math.min(1.0, dot))))
            -- If missile is more in front than rear, reduce effectiveness
            if angle < (180.0 - Config.Flare.rearConeDegrees) then
                hotness = 0.35
            end
        end
    end

    if extraBurst then
        hotness = math.min(1.0, hotness + 0.15)
    end

    return true, hotness
end)
